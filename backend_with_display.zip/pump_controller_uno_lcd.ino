// Pump controller + 16x2 I2C LCD (Arduino Uno). No extra library needed: only Wire (built in).
// LCD backpack (PCF8574) wiring: GND->GND, VCC->5V, SDA->A4, SCL->A5. Pump pins are unchanged.
// If you only see solid blocks, turn the blue contrast trimmer on the back of the LCD.
//
// Pump commands (unchanged):  FIRE id ms speed | START id speed | STOP id | STOPALL
// LCD commands (sent by display.py, replies OK or ERR ...):
//   LCDINIT                 find the LCD (0x27 or 0x3F) and initialise it
//   LCDBL <0|1>             backlight
//   LCDCLR                  clear
//   LCDCHR <slot 0-7> <16 hex chars>    define a custom character
//   LCDROW <row 0-1> <32 hex chars>     write 16 character codes to a row

#include <Wire.h>
#define LCD_I2C_HZ 400000L   // if the LCD shows garbage, change to 100000L

const int PUMP_COUNT = 9;
const int pumpPins[PUMP_COUNT] = {3, 5, 6, 9, 10, 11, 2, 4, 7};

unsigned long endTime[PUMP_COUNT] = {0};
bool running[PUMP_COUNT] = {false};
bool manualHold[PUMP_COUNT] = {false};
String buf = "";

uint8_t lcdAddr = 0;
uint8_t lcdBL = 0x08;
bool lcdOK = false;

// ---------- minimal HD44780 over PCF8574 ----------
void expWrite(uint8_t v) {
  Wire.beginTransmission(lcdAddr);
  Wire.write(v | lcdBL);
  Wire.endTransmission();
}
void lcdNibble(uint8_t nib, uint8_t rs) {
  uint8_t v = (nib << 4) | rs;        // P0=RS P1=RW P2=E P3=BL P4-7=D4-D7
  expWrite(v | 0x04);
  expWrite(v & ~0x04);
  delayMicroseconds(40);
}
void lcdByte(uint8_t b, uint8_t rs) { lcdNibble(b >> 4, rs); lcdNibble(b & 15, rs); }
void lcdCmd(uint8_t c) { lcdByte(c, 0); if (c < 4) delay(2); }
bool i2cPresent(uint8_t a) { Wire.beginTransmission(a); return Wire.endTransmission() == 0; }

bool lcdInit() {
  lcdAddr = 0;
  if (i2cPresent(0x27)) lcdAddr = 0x27;
  else if (i2cPresent(0x3F)) lcdAddr = 0x3F;
  if (!lcdAddr) return false;
  delay(50);
  expWrite(0);
  delay(5);
  lcdNibble(3, 0); delay(5);
  lcdNibble(3, 0); delay(5);
  lcdNibble(3, 0); delay(1);
  lcdNibble(2, 0);                    // 4-bit mode
  lcdCmd(0x28); lcdCmd(0x0C); lcdCmd(0x01); lcdCmd(0x06);
  return true;
}
void lcdText(uint8_t row, const char* s) {
  lcdCmd(0x80 | (row ? 0x40 : 0));
  while (*s) lcdByte(*s++, 1);
}

int hv(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}
bool hexBytes(const String& s, int from, uint8_t* out, int n) {
  if ((int)s.length() < from + 2 * n) return false;
  for (int i = 0; i < n; i++) {
    int a = hv(s[from + 2 * i]), b = hv(s[from + 2 * i + 1]);
    if (a < 0 || b < 0) return false;
    out[i] = (a << 4) | b;
  }
  return true;
}

void handleLcd(const String& line) {
  if (line == "LCDINIT") {
    lcdOK = lcdInit();
    Serial.println(lcdOK ? "OK" : "ERR no_lcd");
    return;
  }
  if (!lcdOK) { Serial.println("ERR no_lcd"); return; }
  if (line.startsWith("LCDBL ")) {
    lcdBL = line.substring(6).toInt() ? 0x08 : 0;
    expWrite(0);
    Serial.println("OK");
    return;
  }
  if (line == "LCDCLR") { lcdCmd(0x01); Serial.println("OK"); return; }
  if (line.startsWith("LCDCHR ")) {
    int slot = line.substring(7, 8).toInt();
    uint8_t d[8];
    if (slot < 0 || slot > 7 || !hexBytes(line, 9, d, 8)) { Serial.println("ERR bad_format"); return; }
    lcdCmd(0x40 | (slot << 3));
    for (int i = 0; i < 8; i++) lcdByte(d[i], 1);
    lcdCmd(0x80);
    Serial.println("OK");
    return;
  }
  if (line.startsWith("LCDROW ")) {
    int row = line.substring(7, 8).toInt();
    uint8_t d[16];
    if (row < 0 || row > 1 || !hexBytes(line, 9, d, 16)) { Serial.println("ERR bad_format"); return; }
    lcdCmd(0x80 | (row ? 0x40 : 0));
    for (int i = 0; i < 16; i++) lcdByte(d[i], 1);
    Serial.println("OK");
    return;
  }
  Serial.println("ERR unknown_command");
}

// ---------- pumps ----------
void setup() {
  Serial.begin(9600);
  for (int i = 0; i < PUMP_COUNT; i++) {
    pinMode(pumpPins[i], OUTPUT);
    analogWrite(pumpPins[i], 0);
  }
  Wire.begin();
  Wire.setClock(LCD_I2C_HZ);
  lcdOK = lcdInit();
  if (lcdOK) { lcdText(0, "  Soda Dispenser"); lcdText(1, "   starting...  "); }
}

void startPump(int idx, int speedPct, unsigned long durationMs, bool hold) {
  int pwmVal = map(constrain(speedPct, 0, 100), 0, 100, 0, 255);
  analogWrite(pumpPins[idx], pwmVal);
  running[idx] = true;
  manualHold[idx] = hold;
  endTime[idx] = hold ? 0 : millis() + durationMs;
}

void stopPump(int idx) {
  analogWrite(pumpPins[idx], 0);
  running[idx] = false;
  manualHold[idx] = false;
}

void handleLine(String line) {
  line.trim();
  if (line.length() == 0) return;

  if (line.startsWith("LCD")) { handleLcd(line); return; }

  if (line == "STOPALL") {
    for (int i = 0; i < PUMP_COUNT; i++) stopPump(i);
    Serial.println("OK");
    return;
  }

  if (line.startsWith("STOP ")) {
    int pumpId = line.substring(5).toInt();
    if (pumpId < 1 || pumpId > PUMP_COUNT) { Serial.println("ERR bad_pump"); return; }
    stopPump(pumpId - 1);
    Serial.println("OK");
    return;
  }

  if (line.startsWith("START ")) {
    int p1 = line.indexOf(' ');
    int p2 = line.indexOf(' ', p1 + 1);
    if (p2 < 0) { Serial.println("ERR bad_format"); return; }
    int pumpId = line.substring(p1 + 1, p2).toInt();
    int speed = line.substring(p2 + 1).toInt();
    if (pumpId < 1 || pumpId > PUMP_COUNT) { Serial.println("ERR bad_pump"); return; }
    startPump(pumpId - 1, speed, 0, true);
    Serial.println("OK");
    return;
  }

  if (line.startsWith("FIRE")) {
    int p1 = line.indexOf(' ');
    int p2 = line.indexOf(' ', p1 + 1);
    int p3 = line.indexOf(' ', p2 + 1);
    if (p1 < 0 || p2 < 0 || p3 < 0) { Serial.println("ERR bad_format"); return; }
    int pumpId = line.substring(p1 + 1, p2).toInt();
    unsigned long ms = line.substring(p2 + 1, p3).toInt();
    int speed = line.substring(p3 + 1).toInt();
    if (pumpId < 1 || pumpId > PUMP_COUNT) { Serial.println("ERR bad_pump"); return; }
    startPump(pumpId - 1, speed, ms, false);
    Serial.println("OK");
    return;
  }

  Serial.println("ERR unknown_command");
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      handleLine(buf);
      buf = "";
    } else if (c != '\r') {
      buf += c;
    }
  }

  unsigned long now = millis();
  for (int i = 0; i < PUMP_COUNT; i++) {
    if (running[i] && !manualHold[i] && now >= endTime[i]) {
      stopPump(i);
      Serial.print("DONE ");
      Serial.println(i + 1);
    }
  }
}
